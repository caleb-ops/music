import pytest


@pytest.fixture(scope="module")
def periscope_kbps():
    return 2500

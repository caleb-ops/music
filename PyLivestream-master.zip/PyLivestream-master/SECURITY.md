# Security Policy

## Supported Versions

The latest release of PyLivestream receives bugfixes and security updates, the older versions are deprecated.

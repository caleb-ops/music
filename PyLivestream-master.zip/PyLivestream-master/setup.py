#!/usr/bin/env python3
import site
import setuptools

# PEP517 workaround
site.ENABLE_USER_SITE = True

setuptools.setup()

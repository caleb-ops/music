---
name: Bug report
about: PyLivestream is a command-line generator for FFmpeg
title: ''
labels: ''
assignees: ''

---

**Describe the bug**


**System Parameters**

* Operating system (Linux, Mac, Windows)
* FFmpeg version
